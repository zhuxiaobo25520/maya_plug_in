ExampleFiles can be automatically downloaded with from the Demo section of the AdvancedSkeleton tools.
Or they can be manually downloaded from:
www.animationstudios.com.au/advancedskeleton/download

Some of the example files require the wbDeltaMushDeformer plugin that comes with AdvancedSkeleton.
If a example file does not load correctly, it might be because this plugin has not been added to "modulePath".
A quick way to fix this, is to drag`n`drop the "setModulePath.mel" file, into any Maya viewport.

If you wish to use any of the AdvancedSkeleton example rigs for any commercial project, please obtain a AdvancedSkeleton license.
For non-commercial projects, such as student work, please add "Rig by AdvancedSkeleton" to the credits,
and if the the project is will be avaiable for viewing online, please email us a link.

Copyright (C) 2016 by AnimationStudios, Oslo, Norway.

Internet: http://www.animationstudios.com.au
Email: support@animationstudios.com.au
